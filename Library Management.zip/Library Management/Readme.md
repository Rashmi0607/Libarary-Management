# Library Management System

## How to Run the Project

1. Clone the repository.
2. Install dependencies by running `pip install -r requirements.txt`.
3. Start the Flask application by running `python app.py`.
4. The API will be accessible at `http://localhost:5000`.

## Design Choices

- **Flask** is used to build the API due to its simplicity and flexibility.
- The **in-memory database** is used for simplicity and testing purposes.
- **Token-based authentication** is implemented to ensure secure access (for bonus).
- **CRUD operations** for `Book` and `Member` are supported with basic search and pagination.

## Assumptions and Limitations

- The system uses in-memory storage, meaning data will be lost when the server is restarted.
- Token authentication is simplified and should be enhanced for a production system.
- The pagination is basic, and no complex sorting or filtering is implemented.
