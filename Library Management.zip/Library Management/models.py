class Book:
    def __init__(self, book_id: int, title: str, author: str, genre: str, year: int):
        self.book_id = book_id
        self.title = title
        self.author = author
        self.genre = genre
        self.year = year

class Member:
    def __init__(self, member_id: int, name: str, email: str, join_date: str):
        self.member_id = member_id
        self.name = name
        self.email = email
        self.join_date = join_date
