import hashlib
from time import time

class TokenAuth:
    def __init__(self):
        self.tokens = {}  # token -> (user_id, expiry_time)

    def generate_token(self, user_id: int) -> str:
        """Generate a token for a user"""
        token = hashlib.sha256(f"{user_id}{time()}".encode()).hexdigest()
        expiry_time = time() + 3600  # Token expires in 1 hour
        self.tokens[token] = (user_id, expiry_time)
        return token

    def validate_token(self, token: str) -> bool:
        """Validate if the token is still valid"""
        user_id, expiry_time = self.tokens.get(token, (None, 0))
        return user_id is not None and expiry_time > time()
