from flask import Blueprint, request, jsonify
from models import Book, Member
from database import InMemoryDatabase

library_db = InMemoryDatabase()
auth = TokenAuth()

# Create a blueprint for the API routes
api_bp = Blueprint('api', __name__)

@api_bp.route('/books', methods=['GET'])
def get_books():
    page = int(request.args.get('page', 1))
    limit = int(request.args.get('limit', 10))
    offset = (page - 1) * limit
    books = library_db.get_all_books(limit, offset)
    return jsonify([book.__dict__ for book in books])

@api_bp.route('/books', methods=['POST'])
def add_book():
    data = request.get_json()
    book_id = len(library_db.books) + 1
    book = Book(book_id, **data)
    library_db.add_book(book)
    return jsonify(book.__dict__), 201

@api_bp.route('/books/<int:book_id>', methods=['GET'])
def get_book(book_id: int):
    book = library_db.get_book(book_id)
    if book:
        return jsonify(book.__dict__)
    return jsonify({'error': 'Book not found'}), 404

@api_bp.route('/books/<int:book_id>', methods=['PUT'])
def update_book(book_id: int):
    data = request.get_json()
    book = Book(book_id, **data)
    library_db.update_book(book_id, book)
    return jsonify(book.__dict__)

@api_bp.route('/books/<int:book_id>', methods=['DELETE'])
def delete_book(book_id: int):
    library_db.delete_book(book_id)
    return jsonify({'message': 'Book deleted'}), 204

@api_bp.route('/search', methods=['GET'])
def search_books():
    query = request.args.get('q', '')
    books = [book for book in library_db.books.values() if query.lower() in book.title.lower() or query.lower() in book.author.lower()]
    return jsonify([book.__dict__ for book in books])

@api_bp.route('/login', methods=['POST'])
def login():
    data = request.get_json()
    # Assume successful login (use proper user validation here)
    token = auth.generate_token(user_id=1)  # Simplified for demo purposes
    return jsonify({'token': token})
