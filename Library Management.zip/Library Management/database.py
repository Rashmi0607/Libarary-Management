from typing import List

class InMemoryDatabase:
    def __init__(self):
        self.books = {}  # book_id -> Book
        self.members = {}  # member_id -> Member

    def add_book(self, book: Book):
        self.books[book.book_id] = book

    def get_book(self, book_id: int) -> Book:
        return self.books.get(book_id)

    def get_all_books(self, limit: int, offset: int) -> List[Book]:
        return list(self.books.values())[offset:offset+limit]

    def update_book(self, book_id: int, book: Book):
        if book_id in self.books:
            self.books[book_id] = book

    def delete_book(self, book_id: int):
        if book_id in self.books:
            del self.books[book_id]

    def add_member(self, member: Member):
        self.members[member.member_id] = member

    def get_member(self, member_id: int) -> Member:
        return self.members.get(member_id)

    def get_all_members(self) -> List[Member]:
        return list(self.members.values())
