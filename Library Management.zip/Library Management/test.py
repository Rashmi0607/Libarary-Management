import unittest
from app import app

class LibraryApiTest(unittest.TestCase):
    
    @classmethod
    def setUpClass(cls):
        cls.client = app.test_client()

    def test_get_books(self):
        response = self.client.get('/api/books')
        self.assertEqual(response.status_code, 200)

    def test_add_book(self):
        response = self.client.post('/api/books', json={
            'title': 'The Great Gatsby',
            'author': 'F. Scott Fitzgerald',
            'genre': 'Fiction',
            'year': 1925
        })
        self.assertEqual(response.status_code, 201)
        
    def test_search_books(self):
        response = self.client.get('/api/search?q=Gatsby')
        self.assertEqual(response.status_code, 200)

if __name__ == '__main__':
    unittest.main()
